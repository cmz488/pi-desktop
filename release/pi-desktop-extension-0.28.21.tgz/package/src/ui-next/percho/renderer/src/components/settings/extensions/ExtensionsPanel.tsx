import { InstalledPackages } from "../../native/NativeResources";
import { useT } from "../../../i18n";
import { useCatalogStore } from "../../../stores/catalog";
import { BrowseSection } from "./BrowseSection";
import { LoadedSection } from "./LoadedSection";

/** 扩展设置面板：浏览社区目录安装 + 查看已加载扩展（分段切换） */
export function ExtensionsPanel() {
	const t = useT();
	const tab = useCatalogStore((s) => s.extensionsTab);
	const setExtensionsTab = useCatalogStore((s) => s.setExtensionsTab);

	return (
		<div>
			<h3 className="text-ui-13 font-medium text-ink">{t("settings.extensions.title")}</h3>
			<p className="mt-0.5 text-ui-11 text-ink-faint">{t("settings.extensions.hint")}</p>
			<div className="mt-3 flex rounded-lg bg-hover p-0.5">
				{(["browse", "installed", "loaded"] as const).map((id) => (
					<button
						key={id}
						type="button"
						className={`flex-1 rounded-md px-3 py-1 text-ui-12 transition-colors ${
							tab === id ? "bg-surface font-medium text-ink shadow-sm" : "text-ink-dim hover:text-ink"
						}`}
						onClick={() => setExtensionsTab(id)}
					>
						{t(`settings.extensions.tab.${id}`)}
					</button>
				))}
			</div>
			<div className="mt-3">
				{tab === "browse" ? (
					<BrowseSection />
				) : tab === "installed" ? (
					<InstalledPackages />
				) : (
					<LoadedSection />
				)}
			</div>
		</div>
	);
}
