import type { ContextUsageInfo } from "@percho/shared";
import { useCallback, useEffect, useRef, useState } from "react";
import { getExecutionApi } from "../environment-api";

/** 触发刷新的事件类型（流式 delta 类高频事件不刷新） */
const REFRESH_EVENTS = new Set([
	"message_end",
	"tool_execution_end",
	"turn_end",
	"agent_settled",
	"compaction_end",
	"session_info_changed",
]);

/** 刷新事件类型集合的类型收窄 */
function isRefreshEvent(type: string): boolean {
	return REFRESH_EVENTS.has(type);
}

/**
 * 上下文使用量 hook（事件驱动刷新）：给定会话 id，返回 { tokens, contextWindow, percent }。
 * sessionId 为 null（新会话页，后端还没有这个会话）时返回 null。ContextRing 与插件 host API 共用，
 * 抽自 ContextRing（行为零变化）。
 */
export function useContextUsage(sessionId: string | null): ContextUsageInfo | null {
	const [usage, setUsage] = useState<ContextUsageInfo | null>(null);
	// 取消标志：sessionId 切换后旧请求的迟到回写不再生效（防闪旧会话数据）
	const generationRef = useRef(0);

	const refresh = useCallback(async () => {
		const generation = ++generationRef.current;
		// 新会话页（null）在后端还不存在，无上下文用量可查
		if (!sessionId) {
			setUsage(null);
			return;
		}
		try {
			const next = await getExecutionApi(sessionId).getContextUsage({ sessionId });
			if (generation === generationRef.current) setUsage(next);
		} catch {
			if (generation === generationRef.current) setUsage(null);
		}
	}, [sessionId]);

	useEffect(() => {
		void refresh();
		return () => {
			generationRef.current += 1;
		};
	}, [refresh]);

	// 事件驱动刷新：每轮结束/工具完成后取一次
	useEffect(() => {
		if (!sessionId) return;
		const off = getExecutionApi(sessionId).onEvent(({ sessionId: sid, event }) => {
			if (sid !== sessionId) return;
      if (event.type === "desktop_snapshot") {
        generationRef.current += 1;
        setUsage(event.usage ?? null);
        return;
      }
      if (!isRefreshEvent(event.type)) return;
			void refresh();
		});
		return off;
	}, [sessionId, refresh]);

	return usage;
}
