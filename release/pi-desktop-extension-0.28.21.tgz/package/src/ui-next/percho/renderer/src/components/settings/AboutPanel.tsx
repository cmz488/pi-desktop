import type { AppInfo, UpdateDiagnosticsInfo } from "@percho/shared";
import { useEffect, useState } from "react";
import { getPi, supportsHostChannel } from "../../api";
import { useT } from "../../i18n";
import { useUpdateStore } from "../../stores/update";
import { UpdateHelp } from "./UpdateHelp";

/** 关于面板：应用标识 + 软件版本 + 检查更新 + 仓库入口，居中展示 */
export function AboutPanel() {
	const t = useT();
	const [info, setInfo] = useState<AppInfo | null>(null);
	const [diagnostics, setDiagnostics] = useState<UpdateDiagnosticsInfo | null>(null);
	const state = useUpdateStore((s) => s.state);
	const [error, setError] = useState<string | null>(null);
	const updates = supportsHostChannel("update:check");
	const diagnosticsAvailable = supportsHostChannel("update:diagnostics");
	const act = async (action: () => Promise<unknown>) => {
		setError(null);
		try {
			await action();
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : String(reason));
		}
	};

	useEffect(() => {
		let cancelled = false;
		void getPi()
			.getAppInfo()
			.then((appInfo) => {
				if (!cancelled) setInfo(appInfo);
			})
			.catch(() => {
				if (!cancelled) setInfo(null);
			});
		if (diagnosticsAvailable)
			void getPi()
				.getUpdateDiagnostics()
				.then((value) => {
					if (!cancelled) setDiagnostics(value);
				})
				.catch(() => {
					if (!cancelled) setDiagnostics(null);
				});
		return () => {
			cancelled = true;
		};
	}, [diagnosticsAvailable]);

	// 状态行文案；downloaded 态按钮语义切换为「重启并安装」；manual 构建（mac 未正式签名）跳 release 页手动下载
	const statusText =
		state?.phase === "checking"
			? t("update.checking")
			: state?.phase === "available"
				? state.manual
					? t("update.availableManual", { version: state.version })
					: t("update.available", { version: state.version })
				: state?.phase === "downloading"
					? t("update.downloading", { percent: state.percent })
					: state?.phase === "downloaded"
						? t("update.downloaded")
						: state?.phase === "not-available"
							? t("update.upToDate")
							: state?.phase === "error"
								? t("update.checkFailed", { message: state.message })
								: null;

	const openReleasePage = async (version: string) => {
		const appInfo = info ?? (await getPi().getAppInfo());
		await getPi().openExternal({ url: `${appInfo.repoUrl}/releases/tag/v${version}` });
	};

	const buttonLabel =
		state?.phase === "downloaded"
			? t("update.installNow")
			: state?.phase === "available" && state.manual
				? t("update.goDownload")
				: t("update.checkForUpdates");

	return (
		<div className="flex flex-col items-center gap-1.5 py-10 text-center">
			<div className="flex h-12 w-12 items-center justify-center rounded-xl bg-ink text-ui-16 font-bold text-on-ink">
				P
			</div>
			<p className="mt-2 text-ui-14 font-semibold text-ink">{info?.name ?? "Percho"}</p>
			<p className="text-ui-11 text-ink-faint">{t("settings.about.poweredBy")}</p>
			<p className="mt-2 font-mono text-ui-12 text-ink-dim">
				{t("settings.about.version")} {info?.version ?? "…"}
			</p>
			<div className="mt-4 flex items-center gap-2">
				{updates && (
					<button
						type="button"
						className="rounded-lg border border-border px-4 py-1.5 text-ui-13 text-ink-2 transition-colors hover:border-border-strong hover:bg-hover hover:text-ink"
						onClick={() => {
							if (state?.phase === "downloaded") act(() => getPi().installUpdate());
							else if (state?.phase === "available" && state.manual)
								act(() => openReleasePage(state.version));
							else act(() => getPi().checkForUpdates());
						}}
					>
						{buttonLabel}
					</button>
				)}
				{info?.repoUrl && (
					<button
						type="button"
						className="rounded-lg border border-border px-4 py-1.5 text-ui-13 text-ink-2 transition-colors hover:border-border-strong hover:bg-hover hover:text-ink"
						onClick={() => act(() => getPi().openExternal({ url: info.repoUrl }))}
					>
						{t("settings.about.sourceCode")}
					</button>
				)}
			</div>
			{statusText && <p className="mt-1 text-ui-11 text-ink-faint">{statusText}</p>}
			{error && (
				<p role="alert" className="mt-2 text-ui-12 text-err">
					{error}
				</p>
			)}
			{info && diagnosticsAvailable && supportsHostChannel("update:exportDiagnostics") && (
				<UpdateHelp
					diagnostics={diagnostics}
					windows={info.platform === "win32"}
					repoUrl={info.repoUrl}
				/>
			)}
		</div>
	);
}
