import {
	isModelVisible,
	type ModelPrefs,
	type ProviderInfo,
	providerModelVisibility,
} from "@percho/shared";
import { supportsHostChannel } from "../../../api";
import { useState } from "react";
import { useEnvironment } from "../../../environment-context";
import { useT } from "../../../i18n";
import { useProviderLoginStore } from "../../../stores/provider-login";
import { useSettingsStore } from "../../../stores/settings";
import {
	EditIcon,
	ExpandArrowIcon,
	LoginIcon,
	TestIcon,
	TrashIcon,
} from "../../icons";
import { Switch } from "../../ui/Switch";
import { Tooltip } from "../../ui/Tooltip";
import { BuiltinProviderEditForm } from "./BuiltinProviderEditForm";
import { CustomProviderEditForm } from "./CustomProviderForm";

const EMPTY_MODEL_PREFS: ModelPrefs = { hiddenModels: {}, subagentModels: {} };

/** 图标操作按钮：图标无文字，Tooltip + aria-label 必需（ProvidersPanel 刷新按钮复用） */
export function IconAction({
	label,
	align,
	danger,
	disabled,
	onClick,
	children,
}: {
	label: string;
	/** 透传给 Tooltip：靠滚动容器右缘的按钮用 "end"，居中气泡会向右溢出被裁 */
	align?: "center" | "end";
	danger?: boolean;
	disabled?: boolean;
	onClick: () => void;
	children: React.ReactNode;
}) {
	return (
		<Tooltip label={label} align={align}>
			<button
				type="button"
				aria-label={label}
				disabled={disabled}
				className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition-colors disabled:opacity-40 ${
					danger
						? "text-ink-dim hover:bg-red-50 hover:text-red-600"
						: "text-ink-dim hover:bg-hover hover:text-ink"
				}`}
				onClick={onClick}
			>
				{children}
			</button>
		</Tooltip>
	);
}

/** 单个 Provider：配置状态徽章 + 图标操作（测试 / 登录（oauth·api_key 交互） / 填 Key / 删除 / 移除凭证） */
export function ProviderRow({ provider }: { provider: ProviderInfo }) {
	const t = useT();
	const removeCredential = useSettingsStore((s) => s.removeCredential);
	const removeCustom = useSettingsStore((s) => s.removeCustom);
	const test = useSettingsStore((s) => s.test);
	const environment = useEnvironment();
	const startLogin = useProviderLoginStore((s) => s.startProviderLogin);
	const loginActive = useProviderLoginStore((s) => s.login !== null);
	const testResult = useSettingsStore((s) => s.testResults[provider.id]);
	const modelPrefs = useSettingsStore((s) => s.modelPrefs) ?? EMPTY_MODEL_PREFS;
	const setModelHidden = useSettingsStore((s) => s.setModelHidden);
	const setProviderModelsHidden = useSettingsStore(
		(s) => s.setProviderModelsHidden,
	);
	/** 有效可见性三态；中间态点击全藏，零目录也可设定源默认策略。 */
	const visibility = providerModelVisibility(
		modelPrefs,
		provider.id,
		provider.models.map((m) => m.id),
	);
	const allVisible = visibility === "visible";
	const allHidden = visibility === "hidden";
	const mixed = visibility === "mixed";
	/** 全字段编辑 vs 端点覆写：有落盘的自定义模型定义或全新 id 走全字段；
	 * 纯 baseUrl 覆写（内置 id、无自定义模型）永远走端点覆写表单——防止保存后同一按钮换表单的跳变 */
	const fullEdit =
		provider.custom && (!provider.overridesBuiltin || (provider.customModels?.length ?? 0) > 0);
	const [editing, setEditing] = useState(false);
	const [modelsOpen, setModelsOpen] = useState(false);

	return (
		<li className="py-2.5">
			<div className="flex items-center gap-1">
				<div className="min-w-0 flex-1">
					<div className="flex items-center gap-1.5">
						<span className="truncate text-ui-13 font-medium text-ink">{provider.name}</span>
						{provider.overridesBuiltin ? (
							<span className="rounded bg-hover px-1.5 py-0.5 text-ui-10 text-ink-dim">
								{t("settings.providers.overrideBuiltin")}
							</span>
						) : provider.custom ? (
							<span className="rounded bg-hover px-1.5 py-0.5 text-ui-10 text-ink-dim">
								{t("settings.providers.custom")}
							</span>
						) : null}
					</div>
					<div className="mt-0.5 flex items-center gap-1 text-ui-11 text-ink-faint">
						{provider.overridesBuiltin && provider.baseUrl && (
							<span className="mr-1 max-w-[220px] truncate text-ui-10 text-ink-dim" title={provider.baseUrl}>
								→ {provider.baseUrl}
							</span>
						)}
						{provider.configured ? (
							<button
								type="button"
								className="flex items-center gap-1 rounded hover:text-ink"
								onClick={() => setModelsOpen((open) => !open)}
								aria-expanded={modelsOpen}
							>
								{t("settings.providers.modelCount", {
									count: provider.models.length,
								})}
								<ExpandArrowIcon
									className={`transition-transform ${modelsOpen ? "rotate-90" : ""}`}
								/>
							</button>
						) : (
							<span>
								{t("settings.providers.modelCount", {
									count: provider.models.length,
								})}
							</span>
						)}
						{provider.configured && provider.authLabel ? ` · ${provider.authLabel}` : ""}
					</div>
				</div>
				<span
					className={`mr-1 shrink-0 rounded-full px-2 py-0.5 text-ui-11 ${
						provider.configured ? "bg-emerald-50 text-emerald-600" : "bg-hover text-ink-faint"
					}`}
				>
					{provider.configured ? t("settings.providers.configured") : t("settings.providers.unconfigured")}
				</span>
				{provider.configured &&
					supportsHostChannel("settings:testProvider") && (
						<IconAction
							label={t("settings.providers.test")}
							disabled={testResult === "testing"}
							onClick={() => void test(provider.id)}
						>
							{testResult === "testing" ? (
								<span className="h-3 w-3 animate-spin rounded-full border-[1.5px] border-current border-t-transparent" />
							) : (
								<TestIcon />
							)}
						</IconAction>
					)}
				{/* label 与 store/backend 的 loginKind 判定同构（oauth 优先）：oauth provider 即使无 loginLabel 也走「订阅登录」文案 */}
				{!provider.custom && (provider.oauth || provider.apiKeyLogin) && (
					<IconAction
						label={
							provider.oauth
								? (provider.oauth.loginLabel ?? t("settings.providers.login"))
								: t("settings.providers.loginApiKey")
						}
						disabled={loginActive || environment.kind === "ssh"}
						onClick={() => void startLogin(provider)}
					>
						<LoginIcon />
					</IconAction>
				)}
				<IconAction
					label={fullEdit ? t("settings.providers.editCustom") : t("settings.providers.builtinEdit")}
					onClick={() => setEditing((v) => !v)}
				>
					<EditIcon />
				</IconAction>
				{provider.custom ? (
					<IconAction label={t("common.delete")} danger onClick={() => void removeCustom(provider.id)}>
						<TrashIcon />
					</IconAction>
				) : (
					provider.configured &&
					provider.authSource === "stored" && (
						<IconAction
							label={t("settings.providers.removeCredential")}
							danger
							onClick={() => void removeCredential(provider.id)}
						>
							<TrashIcon />
						</IconAction>
					)
				)}
				{/* 行末批量开关：一键全显示/全隐藏该 provider 的所有模型（openrouter 这类几百个模型的供应商先全藏再挑）。
					tooltip 右对齐（align=end）：开关紧贴滚动容器右缘，居中气泡会向右溢出 */}
				{supportsHostChannel("settings:setModelHidden") && (
					<Tooltip
						label={
							allHidden
								? t("settings.providers.showAllModels", { name: provider.name })
								: t("settings.providers.hideAllModels", { name: provider.name })
						}
						align="end"
					>
						<Switch
							checked={allVisible}
							indeterminate={mixed}
							onCheckedChange={() =>
								void setProviderModelsHidden(provider.id, !allHidden)
							}
							aria-label={
								allHidden
									? t("settings.providers.showAllModels", {
											name: provider.name,
										})
									: t("settings.providers.hideAllModels", {
											name: provider.name,
										})
							}
						/>
					</Tooltip>
				)}
			</div>
			{testResult && testResult !== "testing" && (
				<p
					className={`mt-1.5 rounded-lg px-2.5 py-1.5 text-ui-11 ${
						testResult.ok ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"
					}`}
				>
					{testResult.ok
						? t("settings.providers.testOk", {
								modelId: testResult.modelId ?? "",
							})
						: t("settings.providers.testFailed", {
								error: testResult.error ?? "",
							})}
				</p>
			)}
			{provider.configured && modelsOpen && provider.models.length > 0 && (
				<div className="mt-2 rounded-lg bg-hover/60 px-2.5 py-2">
					<p className="mb-1 text-ui-10 font-medium text-ink-faint">
						{t("settings.providers.modelVisibility")}
					</p>
					<ul className="space-y-0.5">
						{provider.models.map((model) => {
							const visible = isModelVisible(modelPrefs, provider.id, model.id);
							return (
								<li key={model.id}>
									<div className="flex items-center gap-2 rounded px-1 py-1 text-ui-11 text-ink-dim hover:bg-surface">
										<span className="min-w-0 flex-1 truncate">{model.name}</span>
										<Switch
											disabled={!supportsHostChannel("settings:setModelHidden")}
											checked={visible}
											aria-label={model.name}
											onCheckedChange={(nextVisible) =>
												void setModelHidden(provider.id, model.id, !nextVisible)
											}
										/>
									</div>
								</li>
							);
						})}
					</ul>
				</div>
			)}
			{editing && (
				<div className="mt-2">
					{fullEdit ? (
						<CustomProviderEditForm provider={provider} onDone={() => setEditing(false)} />
					) : (
						<BuiltinProviderEditForm provider={provider} onDone={() => setEditing(false)} />
					)}
				</div>
			)}
		</li>
	);
}
