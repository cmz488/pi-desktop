# Pi 资源会话与 native 桥契约

## 位置与职责

- `src/agent/durable-resources.mjs`：每个受管原生会话（含 owned 子代理）一个 Pi 资源会话宿主（经 `startWebSlot`），把 Pi 的工具、扩展、技能、MCP、交互、包管理与审批能力投影成一个**只读工具来源 + 动作入口**。
- `src/agent/native-runtime.mjs`：把 Durable 的回合镜像成 Pi 会话生命周期事件，并把 Pi 的消息入口委托给当前 Durable Agent。
- `src/server/web.mjs` 的 `startWebSlot(options)`：真正创建 Pi 资源会话的 adapter。

这是 [边界文档](../pi-boundary.md) 的 **seam B（能力 seam）**，也是 [边界规则 R2／R3](../pi-boundary.md) 的执行者。

## 签名

```js
export function createDurableResources({
  agentDir,            // 必需；Pi agent 目录（扩展、技能、MCP 配置所在地）
  onEvent = () => {},  // 可选；资源事件回调
  noExtensions = false,// 可选；不加载用户扩展（受限场景）
  readOnly = false,    // 可选；只读 Agent
  nativeResources = {},// 可选；宿主注入的原生资源实现
  nativeSnapshot,      // 内部；async id -> 同作用域、已经发布的原生转录快照
  durableTools = [],   // 可选；要暴露的 Durable 工具名
  approvalMode = "yolo", // 可选；必须通过 validateApprovalMode
  providers,           // 可选；模型 provider 注册表
  browser,             // 可选；是否装配 agent_browser 工具
}); // -> resources
```

resources 表面：

```js
resources.attach(workspace)                  // 绑定 workspace；预热顶层及仍需恢复的 owned 资源
resources.ensure(active)                     // async -> facade | undefined；active 为 workspace.read() 的 active
resources.normalizeExtensions(names)         // 过滤掉 desk-native:* 前缀
resources.selectTools(active, { defaults = false, newOnly = false })
                                             // async -> facade；把原生工具名写入会话 agent 文档
resources.reload(active)                     // async -> facade；重载扩展/包后重算默认工具集
resources.close()                            // 停止所有资源宿主，幂等
resources.cancelInteractions()               // 取消所有就绪宿主上的待答交互
resources.canWrite()                         // 所有就绪宿主都允许写入时为 true
resources.interactions.list(scope, owner)     // scope 是受信的 owned ID Set；子交互标注来源
resources.interactions.version(scope)         // 只读已就绪宿主的变更位，不启动历史资源
resources.interactions.reply(scope, input)    // 范围内按交互 ID 路由，再校验 prompt ID
```

facade（`Object.freeze`）：

```js
facade.read(); // { snapshot, commands, canWrite, projectTrusted, effectiveSettings }
facade.describe(catalog); // { tools: [...], extensions: [...] }，按 desk-native: scope 过滤
facade.execute(action, ...args);
```

`facade.execute` 的 action 表：

| action                                                                                                                         | 参数                               | 语义                                                     |
| ------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------- | -------------------------------------------------------- |
| `approvalMode`                                                                                                                 | `mode`                             | 修改审批模式（经 `validateApprovalMode`）                |
| `expandPrompt`                                                                                                                 | `message, {original?,requestId?}?` | 展开模板／技能；注册命令另保留只展示原文，不额外发起模型 |
| `packageAction`                                                                                                                | `input`                            | 包管理动作（自动带当前 `sessionId`）                     |
| `interactions.list` / `.reply` / `.version`                                                                                    | 同交互存储                         | 读取／回答／探测交互版本                                 |
| `settingsChanged`、`skillInventory`、`mcpRegistered`、`mcpTools`、`mcpAction`、`trustProject`、`packageRoot`、`packageUpdates` | `...args`                          | 转发给宿主 capability                                    |

native 桥：

```js
export function createNativeRuntime({ workspace, id, nativeSnapshot, ready, syncTools, onError });
// -> { record, stateEntries, withToolContext, initialize, input, systemPrompt, modelRuntime, bind, flush,
//      beforeRequest, afterResponse, afterTools, afterTurn, beforeSettle, dispose }
```

`facade.execute("input", message, {original?,requestId?,images?,source?,mode?})` 在模型准入前处理标准 input：注册命令先于 input，普通输入的 transform／handled 等待 Pi runner，再走既有技能／模板展开。Desktop 的公开技能包装格式保留，模板继续由 Pi 展开；显式请求展开的程序输入走 SDK 的原生技能／模板路径。默认 source 为 rpc；程序用户消息为 extension。返回 `{message,images}` 或 `{handled:true}`。旧 `expandPrompt` 仍保留只展开／命令的兼容 interface；当前 HTTP 输入使用新的完整预处理路径。

`nativeRuntime.input(message, images, options)` 只做原生输入预处理，不接纳模型；原生 custom 消息绕过 input，并通过 workspace 的 entry input 触发 run，不合成用户占位。

`beforeRequest` 保留完整 leading system 并使用 Pi Agent 已装配的 context transform（含 force／hidden declarations），不另写 prompt 覆盖器。before-agent 消息先提交并进入首次请求，structured prompt 替换旧资源 section 而非重复追加基础提示。`systemPrompt()` 给 Durable section 提供不含 request-local force 的结构化文本，不能把临时 override 写回 canonical prompt。助手的 message_end 使用 SDK 同 role 替换与空内容规范化，返回模型消息进入 Durable 提交；旧活动的结束不能清除新活动的 prompt。

`modelRuntime(api, context)` 等待同会话资源后选择 Pi Models；未注册该模型时保持 Durable 默认集合。generation 与 compaction 均在原任务内使用该 resolver。`src/agent/native-model-runtime.mjs` 的 adapter 只借用绑定的 SDK 请求 transport，保留资源 Agent 的 streamFunction 守卫与关闭的 cache warming，不调用资源 prompt／continue。provider headers、payload 变换、响应和原始流 callback 由原 SDK 链路等待；assistant 标准 stream 事件按序投影，不重复 message_start。

`bind(session, {stream})` 的 transport 仅由资源宿主内部传入，不成为浏览器能力或 Pi 扩展的另一执行入口。异步 signal scope 让请求 callback 使用当前 Durable 操作信号，SDK 自身的工具 signal 与 stale guard 继续保留；关闭时清理 scope。

`afterTurn`／`beforeSettle` 在原 GenerationTask 的已提交边界内等待 `runner.emitBoundary`。`messageEntryId`、`toolResultEntryIds` 来自同一原生导出器已经发布的记录与映射；上下文 manager 使用 SDK 的 in-memory load／projection，不以镜像临时 ID 冒充边界身份。turn_start 提供真实顺序的索引和时间；agent_end 先于 agent_before_settle，turn continuation 与 settle continuation 保留各自的 agent loop 事件，不重复 before_agent_start。

`src/agent/native-boundary.mjs` 把 SDK 已校验的四种 draft 转换成原提交的 EntryDraft：private custom、custom_message、context_edit 和 compaction。上下文内容由 Pi preview 推导，来源由持久映射解析；编辑不覆盖原记录，压缩复用 Durable head，null 的自保留语义由 SDK 规范化。返回的继续决策须满足原生 runnable context；取消后迟到的 draft／continue 仍被原任务拒绝。每个 handler 后由同一原生 dispatcher 重新构建 preview：先完成此前 handler 的消息准入，再读取 Durable inbox 和已发布上下文，后续 handler 不会看到旧 pending 列表。

`stateEntries()` 是扩展 custom 状态的唯一提取 interface。工具事务与消息／生命周期保存都复用它，排除 Desktop 的配置、来源和导出检查点，不能把 canonical 转录元数据回灌成扩展状态。

`withToolContext(context, execute)` 在 SDK 执行前载入已经提交的助手／调用记录，并把当前 Durable 工具信号绑定到原生 context。资源工具复用同 SDK core 的 runToolCall：参数准备／验证、tool_call 门禁、执行、等待在途 update、tool_result 与图像规范化均由原生 pipeline 拥有。adapter 只按真实操作发出 start／update／end 和 toolResult 消息；message_end 同 role 替换先消费，再回到唯一 ToolTask 提交，usage 不丢失。嵌套调用保持原生父 ID 和 callable tools；SDK 的迟到 update fence 保持，不从网页观察重发工具。

## 不变量

- **owned 资源 scope 独立**：发起前绑定子会话自己的工具 scope，恢复时也先于 Harness resume 注册；不会为此创建第二个 worker／SQLite，也不借用父会话工具闭包。`attach` 在 workspace 显式声明 `spawnSubagent` 时注册其 owned preparer；具体契约见 [Host 任务](host-tasks.md)。
- **审批与交互**：默认 Desktop 的审批模式存在 worker 范围的 workspace 文档中，不随历史退回／分叉恢复旧值，owned 子代理继承有效策略；Host 显式启动策略先于恢复应用到 worker，不能被存量子会话覆盖。聚合交互只含当前 owned 范围，子会话条目带 `sourceConversationId` 和名称；历史 fork 无权代答。工具执行边界重新读取当前审批策略，原生自动输入不能依赖 HTTP 页面刷新来更新资源宿主中的旧策略。
- **资源回收**：委托终态且子会话工作已结束后，先完成原生结束事件及状态写回，再释放宿主和其工具 scope。若结束事件产生新工作则暂不释放；重启只预热活跃／待恢复 owned 会话，历史详情不装载 SDK 资源。异步维护失败通过通知保留错误上下文，不静默吞掉。
- **输入来源**：宿主在展开前捕获用户原文；原生程序发送标注为 automatic，注册命令的只展示记录与模型贡献分开。可靠关联、继承与兼容回退见[输入展示契约](input-presentation.md)。
- **资源会话不跑模型循环**：它只提供工具与交互；所有被接受的模型回合都由 Durable 拥有（源码注释：`The resource Session never runs a second model loop`）。
- **执行由 Durable 拥有**：原生 input 的返回只进入既有准入；已接受模型工作的生命周期来自 Durable 回调与提交。Pi 事件 handler 的修改通过定义的 seam 等待和消费，不能从页面观察、刷新或事件回放重新发起执行。
- **`ensure(active)` 幂等且按会话缓存**：同一 `active.id` 在资源存活期间复用 facade；目录变化或资源已回收后，显式调用可按需重新创建。
- **`attach(workspace)` 先于任何 `ensure`**：没有 workspace 时无法读取 agent 文档，`ensure` 也不会得到完整 facade。
- **扩展名过滤**：写入会话文档的扩展名必须经 `normalizeExtensions`，`desk-native:*` 只保留当前 scope，避免跨 Agent 串用。
- **只读不改变形状**：`readOnly` 只影响工具选择（排除 `read`／`write`／`edit`／`bash` 的原生重装）与写入权限，不改变 facade 表面。
- **`canWrite()` 是聚合判断**：任一就绪宿主不允许写入即返回 `false`。

## 顺序约束

1. `attach(workspace)` → `ensure(active)`。
2. 新建或切换会话后调用 `selectTools(active, { defaults: true })`；只在需要补齐新工具时用 `newOnly: true`（它会在扩展缺失时提前返回）。
3. `reload(active)` 之后必须重新 `selectTools(..., { defaults: true, newOnly: true })`，否则新加载的工具不会进入会话 agent 文档。
4. `close()` 在 worker 停止路径上调用；之后任何 `ensure` 调用都不再返回宿主。
5. `nativeRuntime.bind(session)` 与 `initialize()` 必须在 Pi 会话创建之后、session_start 之前完成；先注册 Durable 工具，再建立／导入 canonical 转录，最后给资源 manager 载入同一 header 和已提交记录。初始绑定可异步等待这一局部就绪，不等待插件可能打开的启动对话框。`bind` 必须在首次 `beforeRequest` 之前调用（`bind` 会接管 `sendUserMessage`／`sendCustomMessage` 并包装 `createContext`）。重载使用 SDK 的 `beforeSessionStart` seam，先失效旧 runner，再清理旧展示并给 fresh runner 绑定，最后才让新的 `session_start` handler 运行；不额外调用一次 `bindExtensions()` 来制造重复启动事件。标准 command context 的 `reload()` 与宿主重载共用该路径。
6. 桥接的 `isIdle`、`hasPendingMessages`、`signal`、`abort` 保留 Pi 的 context 失效错误；旧 context 不能读取新回合 signal，或中止重载后的会话。重载／换会话清除旧状态、working／streaming 展示并释放旧 widget。

## 错误模式

| 条件                                                                 | 结果                                                                                  |
| -------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| `approvalMode` 非法                                                  | `validateApprovalMode` 抛出 `DeskError`                                               |
| `expandPrompt` 给的 `/命令` 既不是命令、也不是模板、也不是已加载技能 | `DeskError(422, "未知 Pi 命令")`；技能名存在但未加载 → `DeskError(422, "技能未加载")` |
| `interactions.<method>` 不在 `list`／`reply`／`version` 内           | `DeskError(404, "资源交互操作无效")`                                                  |
| action 不在允许集合内                                                | `DeskError(404, "原生资源操作无效")`                                                  |
| 宿主 capability 缺失（例如 `mcpAction` 未声明）                      | `capabilities[action]?.(...)` 返回 `undefined`；调用方按 capability 声明处理          |

## 性能特征

- **每 Agent 一个资源宿主**，宿主创建包含 Pi 会话与扩展装载，成本高，因此按 `active.id` 缓存，终态 owned 宿主及时释放，`close()` 释放剩余宿主。
- `selectTools` 每次调用都会写一次会话 agent 文档（`configure`），属写路径；不要在热路径反复调用。
- `cancelInteractions()` 只遍历就绪宿主，未就绪宿主不产生成本。
- 资源宿主是 SDK 唯一需要完整命名空间的地方；启动关键路径不得等待它（见 [pi-sdk 适配层](pi-sdk-adapter.md)）。

## 可执行证据

- `test/native-extension-boundary.test.mjs`：真实 Host 的已发布 ID／preview、turn／settle 继续、四种 draft、稳定会话 header、取消中的迟到决策，以及观察不重放；无状态工具不会把检查点回灌成扩展状态。
- `test/native-runtime-lifecycle.test.mjs`：真实 SDK context 的 stale guard；原生安装包在新 `session_start` 前获得正确 signal／idle、标准命令重载路径、唯一命令和卸载状态清理。
- `test/standard-extension-baseline.test.mjs`：真实 Pi 安装的两个普通扩展、发现／过滤／重载、工具／命令与原生对照；这是调查基线，不把事件／交互缺口列为已支持，详见[兼容矩阵](../../references/pi-extension-compatibility-baseline.md)。
- `test/durable-features.test.mjs`：工具可用性、权限门控、ask_user／MCP 交互、启动对话框与 `agent_browser` 注册。
- `test/subagent-reliability.test.mjs`：审批继承、停机权限变更、owned 交互、终态释放与历史不预热；浏览器工作台回归覆盖父界面批准／拒绝。
- `test/pi-permissions.test.mjs`：审批模式与权限钩子。
- `test/agent-browser.test.mjs`：`agent_browser` 工具经资源会话可用。
- `test/pi-sdk-lazy.test.mjs`：导入 worker 模块图不会加载 SDK 命名空间（资源会话按需创建）。
- 接口形状断言：`test/boundary-contracts.test.mjs` —— 重命名或删除本页列出的键、命令或深路径时该测试失败。
